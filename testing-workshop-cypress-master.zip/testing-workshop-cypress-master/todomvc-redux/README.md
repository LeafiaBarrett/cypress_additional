# TodoMVC with Redux

> Todo: describe what this application is for and how to demo it
