// little reusable functions for our tests
// like "resetData" and "visitSite"
