// import todo page object from "todo-page-object.js"
describe('TodoMVC with Page Object', () => {
  beforeEach(() => {
    // visit the page
  })

  it('creates 3 todos', () => {
    // create default todos
    // and check that there are 3 of them
  })

  context('toggles items', () => {
    beforeEach(() => {
      // what should you do before each test?
    })

    it('completes second item', () => {
      // toggle 1 item
      // check class names for all 3 items
    })
  })
})
